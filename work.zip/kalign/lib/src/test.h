#ifndef TEST_H
#define TEST_H

int sub(int a, int b);
#endif
